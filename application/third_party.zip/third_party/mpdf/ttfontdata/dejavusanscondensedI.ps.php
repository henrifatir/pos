<?php 
$originalsize=573136;
?>