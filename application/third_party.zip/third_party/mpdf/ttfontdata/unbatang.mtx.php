<?php
$name='UnBatang';
$type='TTF';
$desc=array (
  'CapHeight' => 692,
  'XHeight' => 490,
  'FontBBox' => '[-1037 -250 1080 970]',
  'Flags' => 4,
  'Ascent' => 970,
  'Descent' => -250,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$unitsPerEm=1000;
$up=-125;
$ut=50;
$strp=258;
$strs=49;
$ttffile='C:/xampp/htdocs/test/mpdf/ttfonts/UnBatang_0613.ttf';
$TTCfontID='0';
$originalsize=6937228;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='unbatang';
$panose=' 0 0 4 b 6 0 0 1 1 1 1 1';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 800, -200, 0
// usWinAscent/usWinDescent = 970, -250
// hhea Ascent/Descent/LineGap = 970, -250, 0
$useOTL=0x0000;
$rtlPUAstr='';
?>