<?php 
$originalsize=611948;
?>