<?php 
$originalsize=610680;
?>