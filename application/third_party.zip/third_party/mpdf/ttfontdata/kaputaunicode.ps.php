<?php 
$originalsize=148720;
?>