<?php

$rtlSUB = array (
 "00622" => array ( 2 => "0FE81", 3 => "0FE82", 1 => "0FE82",),
 "00623" => array ( 2 => "0FE83", 3 => "0FE84", 1 => "0FE84",),
 "00624" => array ( 1 => "0FE86",),
 "00625" => array ( 2 => "0FE87", 3 => "0FE88", 1 => "0FE88",),
 "00626" => array ( 2 => "0FE8B", 3 => "0FE8C", 1 => "0FE8A",),
 "00627" => array ( 2 => "0FE8D", 3 => "0FE8E", 1 => "0FE8E",),
 "00628" => array ( 2 => "0FE91", 3 => "0FE92", 1 => "0FE90",),
 "00629" => array ( 2 => "0FE93", 3 => "0FE93", 1 => "0FE94",),
 "0062A" => array ( 2 => "0FE97", 3 => "0FE98", 1 => "0FE96",),
 "0062B" => array ( 2 => "0FE9B", 3 => "0FE9C", 1 => "0FE9A",),
 "0062C" => array ( 2 => "0FE9F", 3 => "0FEA0", 1 => "0FE9E",),
 "0062D" => array ( 2 => "0FEA3", 3 => "0FEA4", 1 => "0FEA2",),
 "0062E" => array ( 2 => "0FEA7", 3 => "0FEA8", 1 => "0FEA6",),
 "0062F" => array ( 2 => "0FEA9", 3 => "0FEA9", 1 => "0FEAA",),
 "00630" => array ( 2 => "0FEAB", 3 => "0FEAB", 1 => "0FEAC",),
 "00631" => array ( 2 => "0FEAD", 3 => "0FEAE", 1 => "0FEAE",),
 "00632" => array ( 2 => "0FEAF", 3 => "0FEB0", 1 => "0FEB0",),
 "00633" => array ( 2 => "0FEB3", 3 => "0FEB4", 1 => "0FEB2",),
 "00634" => array ( 2 => "0FEB7", 3 => "0FEB8", 1 => "0FEB6",),
 "00635" => array ( 2 => "0FEBB", 3 => "0FEBC", 1 => "0FEBA",),
 "00636" => array ( 2 => "0FEBF", 3 => "0FEC0", 1 => "0FEBE",),
 "00637" => array ( 2 => "0FEC3", 3 => "0FEC4", 1 => "0FEC2",),
 "00638" => array ( 2 => "0FEC7", 3 => "0FEC8", 1 => "0FEC6",),
 "00639" => array ( 2 => "0FECB", 3 => "0FECC", 1 => "0FECA",),
 "0063A" => array ( 2 => "0FECF", 3 => "0FED0", 1 => "0FECE",),
 "00641" => array ( 2 => "0FED3", 3 => "0FED4", 1 => "0FED2",),
 "00642" => array ( 2 => "0FED7", 3 => "0FED8", 1 => "0FED6",),
 "00643" => array ( 2 => "0FEDB", 3 => "0FEDC", 1 => "0FEDA",),
 "00644" => array ( 2 => "0FEDF", 3 => "0FEE0", 1 => "0FEDE",),
 "00645" => array ( 2 => "0FEE3", 3 => "0FEE4", 1 => "0FEE2",),
 "00646" => array ( 2 => "0FEE7", 3 => "0FEE8", 1 => "0FEE6",),
 "00647" => array ( 2 => "0FEEB", 3 => "0FEEC", 1 => "0FEEA",),
 "00648" => array ( 2 => "0FEED", 3 => "0FEEE", 1 => "0FEEE",),
 "00649" => array ( 2 => "0FBE8", 3 => "0FBE9", 1 => "0FEF0",),
 "0064A" => array ( 2 => "0FEF3", 3 => "0FEF4", 1 => "0FEF2",),
 "00671" => array ( 1 => "0FB51",),
 "00679" => array ( 2 => "0FB68", 3 => "0FB69", 1 => "0FB67",),
 "0067A" => array ( 2 => "0FB60", 3 => "0FB61", 1 => "0FB5F",),
 "0067B" => array ( 2 => "0FB54", 3 => "0FB55", 1 => "0FB53",),
 "0067E" => array ( 2 => "0FB58", 3 => "0FB59", 1 => "0FB57",),
 "0067F" => array ( 2 => "0FB64", 3 => "0FB65", 1 => "0FB63",),
 "00680" => array ( 2 => "0FB5C", 3 => "0FB5D", 1 => "0FB5B",),
 "00683" => array ( 2 => "0FB78", 3 => "0FB79", 1 => "0FB77",),
 "00684" => array ( 2 => "0FB74", 3 => "0FB75", 1 => "0FB73",),
 "00686" => array ( 2 => "0FB7C", 3 => "0FB7D", 1 => "0FB7B",),
 "00687" => array ( 2 => "0FB80", 3 => "0FB81", 1 => "0FB7F",),
 "00691" => array ( 1 => "0FB8D",),
 "00698" => array ( 1 => "0FB8B",),
 "006A4" => array ( 2 => "0FB6C", 3 => "0FB6D", 1 => "0FB6B",),
 "006A6" => array ( 2 => "0FB70", 3 => "0FB71", 1 => "0FB6F",),
 "006A9" => array ( 2 => "0FB90", 3 => "0FB91", 1 => "0FB8F",),
 "006AD" => array ( 2 => "0FBD5", 3 => "0FBD6", 1 => "0FBD4",),
 "006AF" => array ( 2 => "0FB94", 3 => "0FB95", 1 => "0FB93",),
 "006B1" => array ( 2 => "0FB9C", 3 => "0FB9D", 1 => "0FB9B",),
 "006B3" => array ( 2 => "0FB98", 3 => "0FB99", 1 => "0FB97",),
 "006BA" => array ( 1 => "0FB9F",),
 "006BB" => array ( 2 => "0FBA2", 3 => "0FBA3", 1 => "0FBA1",),
 "006C0" => array ( 1 => "0FBA5",),
 "006C1" => array ( 2 => "0FBA8", 3 => "0FBA9", 1 => "0FBA7",),
 "006CC" => array ( 2 => "0FBFE", 3 => "0FBFF", 1 => "0FBFD",),
 "006D0" => array ( 2 => "0FBE6", 3 => "0FBE7", 1 => "0FBE5",),
 "006D2" => array ( 2 => "0FBFE", 3 => "0FBFF", 1 => "0FBAF",),
 "006D3" => array ( 1 => "0FBB1",),
);
$finals = '0FE82 0FE84 0FE88 0FE8A 0FE90 0FE96 0FE9A 0FE9E 0FEA6 0FEAC 0FEB0 0FEB2 0FEB6 0FEBA 0FEBE 0FEC6 0FECE 0FEE2 0FEE6 0FEEA 0FB67 0FB5F 0FB53 0FB57 0FB63 0FB5B 0FB77 0FB73 0FB7B 0FB7F 0FB6B 0FB6F 0FB8F 0FBD4 0FB9B 0FB97 0FBA1 0FBA7 0FBFD 0FBE5 0FBAF 0FE86 0FB51 0FB8D 0FB8B 0FB9F 0FBA5 0FBB1 ';
$rphf = array (
);
$half = array (
);
$pref = array (
);
$blwf = array (
);
$pstf = array (
);

 
?>